package CassioDiasCassiminhoExerc1B;

/**
 * @author Cassio Dias Cassiminho - Nivelamento PIPCA
 * @date 26/02/2013
 * 
 * cassio.dias.25@gmail.com
 */
public class IniciarJogoDaVelha {

    public static void main(String[] args) {
	new JogoDaVelha().start();
    }
   
}
